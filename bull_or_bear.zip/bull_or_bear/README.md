# BULL OR BEAR 🎮
### Juego de Inversiones - Feria Vocacional ACCOUNTING 2026

## Descripción
Juego educativo de predicción de mercados financieros con estética cyberpunk/neón.
Desarrollado para la feria vocacional de la especialidad de Accounting del COVAO.

## Archivos
- `index.html` → El juego completo (todo en un solo archivo)

## Cómo correr
Simplemente abre `index.html` en cualquier navegador.
No requiere servidor, no requiere internet, funciona 100% offline.

## Características
- 2 niveles: Bull or Bear (estándar) y Financial Controller (difícil 🔥)
- 3 activos: Stocks, Crypto, Bonds
- 10 rondas por juego con dificultad progresiva
- Preguntas bilingües (Inglés + Español)
- Sistema de puntos según dificultad
- Top 5 del día
- Interfaz cyberpunk con animaciones

## Tecnologías
- HTML5 / CSS3 / JavaScript puro
- Canvas API (gráfica de mercado + llamas FC)
- Sin dependencias externas

## Contacto
@accountingcovao
